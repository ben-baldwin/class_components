import React, { Component } from 'react';

class PersonCard extends Component{
    constructor(props){
        super (props)
    }
    render(){
        return(
            <div>
                <h1>{this.props.person.lastName},{this.props.person.firstName}</h1>
                <p>{this.props.person.age}</p>
                <p>{this.props.person.hairColor}</p>
            </div>
        );
    }
}

export default PersonCard;